/* ==========================================================================
   AI MASTERS · INTERAÇÕES
   - Scroll-triggered reveals via Intersection Observer
   - Contadores animados nas stats
   - Nav background condicional
   - Sem dependências externas, deploy direto GitHub Pages
   ========================================================================== */

(() => {
  'use strict';

  /* -------------- SCROLL REVEAL -------------- */
  // Reveals elementos quando entram na viewport
  // Lê data-delay para staggers manuais

  const revealEls = document.querySelectorAll('.reveal');

  // Aplica delays via CSS custom property
  revealEls.forEach(el => {
    const delay = el.dataset.delay || 0;
    el.style.setProperty('--reveal-delay', delay);
  });

  const revealObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          revealObserver.unobserve(entry.target);
        }
      });
    },
    {
      threshold: 0.12,
      rootMargin: '0px 0px -60px 0px'
    }
  );

  revealEls.forEach((el) => revealObserver.observe(el));

  /* -------------- STAGGER WITHIN GRIDS -------------- */
  // Cards (pilares, timeline, dimensions) ganham stagger automático
  // baseado em sua posição dentro do parent

  const staggerGroups = [
    { selector: '.pilares__grid .pilar', step: 80 },
    { selector: '.timeline__item', step: 100 },
    { selector: '.dimensions li', step: 70 },
  ];

  staggerGroups.forEach(({ selector, step }) => {
    document.querySelectorAll(selector).forEach((el, i) => {
      el.style.setProperty('--reveal-delay', i * step);
    });
  });

  /* -------------- ANIMATED COUNTERS -------------- */
  // Stats que sobem de 0 até o valor de data-count

  const counters = document.querySelectorAll('.stat__num[data-count]');

  const animateCount = (el) => {
    const target = parseInt(el.dataset.count, 10);
    const duration = 1500;
    const startTime = performance.now();

    const tick = (now) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Easing - easeOutCubic
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = Math.round(target * eased);
      el.textContent = current;

      if (progress < 1) {
        requestAnimationFrame(tick);
      } else {
        el.textContent = target;
      }
    };

    requestAnimationFrame(tick);
  };

  const counterObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          animateCount(entry.target);
          counterObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.5 }
  );

  counters.forEach((c) => counterObserver.observe(c));

  /* -------------- ANUARIO ART OBSERVER -------------- */
  // Trigger especial para a animação do livro

  const bookArt = document.querySelector('.anuario__art');
  if (bookArt) {
    const bookObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in-view');
            bookObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.3 }
    );
    bookObserver.observe(bookArt);
  }

  /* -------------- NAV SCROLL STATE -------------- */
  // Adiciona contraste no nav após scrollar

  const nav = document.querySelector('.nav');
  let lastScroll = 0;

  const handleScroll = () => {
    const y = window.scrollY;
    if (y > 60) {
      nav.style.background = 'rgba(245, 239, 230, 0.92)';
      nav.style.boxShadow = '0 1px 20px -10px rgba(26, 22, 18, 0.15)';
    } else {
      nav.style.background = 'rgba(245, 239, 230, 0.7)';
      nav.style.boxShadow = 'none';
    }
    lastScroll = y;
  };

  // Passive listener para performance
  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();

  /* -------------- SMOOTH SCROLL OFFSET -------------- */
  // Compensa a nav fixa nos links âncora

  document.querySelectorAll('a[href^="#"]').forEach((link) => {
    link.addEventListener('click', (e) => {
      const href = link.getAttribute('href');
      if (href === '#' || href.length < 2) return;
      const target = document.querySelector(href);
      if (!target) return;
      e.preventDefault();
      const navHeight = nav.offsetHeight;
      const top = target.getBoundingClientRect().top + window.scrollY - navHeight - 16;
      window.scrollTo({ top, behavior: 'smooth' });
    });
  });

  /* -------------- HERO PARALLAX (subtle) -------------- */
  // Mantém o feel de motion sem pesar

  const heroArt = document.querySelector('.hero__art');
  if (heroArt && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    let ticking = false;
    window.addEventListener('scroll', () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          const y = window.scrollY;
          if (y < 800) {
            heroArt.style.transform = `translateY(${y * 0.06}px)`;
          }
          ticking = false;
        });
        ticking = true;
      }
    }, { passive: true });
  }
})();
